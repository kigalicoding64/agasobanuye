import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const MOVIES = [
  { title: "Inzozi za Kigali", slug: "inzozi-za-kigali", category: "original", genre: "Drama", isVip: true, isPpv: false, releaseYear: 2025, durationMinutes: 118, description: "A young architect returns to Kigali and must reconcile ambition with family expectations." },
  { title: "Umuhanda w'Amahirwe", slug: "umuhanda-wamahirwe", category: "trending", genre: "Action", isVip: false, isPpv: true, priceRwf: 1500, releaseYear: 2025, durationMinutes: 132, description: "Two estranged brothers cross the country to outrun a debt threatening their family's land." },
  { title: "Ishyamba ry'Ibanga", slug: "ishyamba-ryibanga", category: "trending", genre: "Documentary", isVip: false, isPpv: false, releaseYear: 2024, durationMinutes: 95, description: "An intimate look at the rangers protecting Nyungwe's last forests." },
  { title: "Gusubira Iwacu", slug: "gusubira-iwacu", category: "new", genre: "Drama", isVip: true, isPpv: false, releaseYear: 2026, durationMinutes: 110, description: "A diaspora family's first trip home in a decade unearths old wounds." },
  { title: "Umubyeyi", slug: "umubyeyi", category: "original", genre: "Drama", isVip: true, isPpv: false, releaseYear: 2024, durationMinutes: 121, description: "A rural midwife fights to keep her clinic open against a new policy." },
  { title: "Ubwenge bw'Umugabo", slug: "ubwenge-bwumugabo", category: "comedy", genre: "Comedy", isVip: false, isPpv: false, releaseYear: 2026, durationMinutes: 98, description: "A taxi-moto driver accidentally becomes a chaotic local campaign manager." },
];

async function main() {
  const passwordHash = await bcrypt.hash("Admin123!", 10);

  await prisma.user.upsert({
    where: { email: "admin@iwacumovies.com" },
    update: {},
    create: {
      name: "Iwacu Admin",
      email: "admin@iwacumovies.com",
      passwordHash,
      role: "ADMIN",
    },
  });

  for (const m of MOVIES) {
    await prisma.movie.upsert({
      where: { slug: m.slug },
      update: {},
      create: m as any,
    });
  }

  console.log("Seed complete. Admin login: admin@iwacumovies.com / Admin123! (change immediately).");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
